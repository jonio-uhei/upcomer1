//ヘッダーナビをマウスオーバーした時のテキストの変化
$(function(){
  $('.change1').hover(function(){
    $('.change1').text('トップ').addClass('u-js-text-change1');
  },function(){
    $('.change1').text('Top').removeClass('u-js-text-change1');
  });
  $('.change2').hover(function(){
    $('.change2').text('目的検索').addClass('u-js-text-change2');
  },function(){
    $('.change2').text('Search').removeClass('u-js-text-change2');
  });
  $('.change3').hover(function(){
    $('.change3').text('機能一覧').addClass('u-js-text-change3');
  },function(){
    $('.change3').text('Function').removeClass('u-js-text-change3');
  });
  $('.change4').hover(function(){
    $('.change4').text('事例紹介').addClass('u-js-text-change4');
  },function(){
    $('.change4').text('Case').removeClass('u-js-text-change4');
  });
  $('.change5').hover(function(){
    $('.change5').text('セキュリティ').addClass('u-js-text-change5');
  },function(){
    $('.change5').text('Security').removeClass('u-js-text-change5');
  });
  $('.change6').hover(function(){
    $('.change6').text('デモ体験').addClass('u-js-text-change6');
  },function(){
    $('.change6').text('Trial').removeClass('u-js-text-change6');
  });
  $('.change7').hover(function(){
    $('.change7').text('料金').addClass('u-js-text-change7');
  },function(){
    $('.change7').text('Price').removeClass('u-js-text-change7');
  });
  $('.change8').hover(function(){
    $('.change8').text('オプション').addClass('u-js-text-change8');
  },function(){
    $('.change8').text('Option').removeClass('u-js-text-change8');
  });
})


//ここからスムーススクロール
// $(function(){
//   // #で始まるアンカーをクリックした場合に処理
//       $('a[href^="#"]').click(function() {
//           // スクロールの速度
//           var speed = 500; // ミリ秒
//           // 移動先を取得
//           var href= $(this).attr("href");
//           var target = $(href == "#" || href == "" ? 'html' : href);
//           // 移動先を数値で取得
//           var position = target.offset().top;
//           // スムーススクロール
//           $('body,html').animate({scrollTop:position}, speed, 'swing');
//           return false;
//       });
//   });
//ここまでスムーススクロール


//マウスオーバーで矢印の色が変わるのとモーダルが出る
$(function(){
  $('.c-arrow1').hover(
    function(){
      $(this).find('.c-arrow1__circle,.c-arrow1__line').css('background-color','#4197c7');
      $(this).find('.c-arrow1__chevron').css('border-right','8px solid #4197c7');
      $(this).find('.c-arrow1__chevron').css('border-bottom','8px solid #4197c7');
      
      $(this).find('.c-modal1').addClass('u-js-background1');
    },
    function(){
      $(this).find('.c-arrow1__circle,.c-arrow1__line').css('background-color','#cdcbcb');
      $(this).find('.c-arrow1__chevron').css('border-right','8px solid #cdcbcb');
      $(this).find('.c-arrow1__chevron').css('border-bottom','8px solid #cdcbcb');
      $('.c-arrow1').removeClass('u-bg1');
      $(this).find('.c-modal1').removeClass('u-js-background1');
    }
  );


  $('.c-arrow1').hover(
    function(){
      $('.c-arrow2').css('z-index','-3');
    },
   //  function(){
   //    $('.c-arrow1').css('z-index','0');
   //  }
  );

//   $('.c-arrow1').hover({
//     function(){
//       $('.c-arrow').addClass('u-bg');
//       $('.c-arrow1').css('z-index','3');
//     }
//   })

  
});


//slick
$(function(){
  $('.slick').slick({
    autoplay: true, //自動再生
    focusOnSelect: true,
    arrows: false,
    slidesToShow:3,
    dots:true,
    speed:300

  });
});


//タブの切り替え
$(function(){
  let tabs = $(".u-js-tab");
  $(".u-js-tab").on("click",function(){
    $(".u-js-active").removeClass("u-js-active");
    $(this).addClass("u-js-active");
    const index = tabs.index(this);
    $(".u-js-content").removeClass("u-js-show").eq(index).addClass("u-js-show");
  });
});






// //chart.jsの保管用
// var ctx = document.getElementById("graph-area1").getContext('2d');
// // ctx.canvas.height = 280;
// var myChart = new Chart(ctx, {
//   type: 'pie',
//   data: {
//    labels: ["M", "T", "W"],
//     datasets: [{
//       backgroundColor: [
//         "#fff33f",
//         "#f39800",
//         "#009e96"
//       ],
//       data: [22, 15, 3]
//     }]
//   },
//   options: {
//    maintainAspectRatio: false,     //これでチャートのサイズのしていができるようになる
//    }
// });
// Chart.plugins.register({
//     afterDatasetsDraw: function (chart, easing) {
//         // To only draw at the end of animation, check for easing === 1
//         var ctx = chart.ctx;

//         chart.data.datasets.forEach(function (dataset, i) {
//             var meta = chart.getDatasetMeta(i);
//             if (!meta.hidden) {
//                 meta.data.forEach(function (element, index) {
//                     // Draw the text in black, with the specified font
//                     ctx.fillStyle = 'rgb(255, 255, 255)';

//                     var fontSize = 15;
//                     var fontStyle = 'normal';
//                     var fontFamily = 'Helvetica Neue';
//                     ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

//                     // Just naively convert to string for now
//                     var dataString = dataset.data[index].toString();

//                     // Make sure alignment settings are correct
//                     ctx.textAlign = 'center';
//                     ctx.textBaseline = 'middle';

//                     var padding = 5;
//                     var position = element.tooltipPosition();
//                     ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);
//                 });
//             }
//         });
//     }
// });

var ctx = document.getElementById("graph-area1").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
   labels: ["M", "T", "W"],
    datasets: [{
      backgroundColor: [
        "#fff33f",
        "#f39800",
        "#009e96"
      ],
      data: [22, 15, 3]
    }]
  },
  options: {
   maintainAspectRatio: false,     //これでチャートのサイズのしていができるようになる
   }
});
Chart.plugins.register({
    afterDatasetsDraw: function (chart, easing) {
        // To only draw at the end of animation, check for easing === 1
        var ctx = chart.ctx;

        chart.data.datasets.forEach(function (dataset, i) {
            var meta = chart.getDatasetMeta(i);
            if (!meta.hidden) {
                meta.data.forEach(function (element, index) {
                    // Draw the text in black, with the specified font
                    ctx.fillStyle = 'rgb(255, 255, 255)';

                    var fontSize = 15;
                    var fontStyle = 'normal';
                    var fontFamily = 'Helvetica Neue';
                    ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                    // Just naively convert to string for now
                    var dataString = dataset.data[index].toString();

                    // Make sure alignment settings are correct
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';

                    var padding = 5;
                    var position = element.tooltipPosition();
                    ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);
                });
            }
        });
    }
});
var ctx = document.getElementById("graph-area2").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
   labels: ["M", "T", "W"],
    datasets: [{
      backgroundColor: [
        "#fff33f",
        "#f39800",
        "#009e96"
      ],
      data: [22, 15, 3]
    }]
  },
  options: {
   maintainAspectRatio: false,     //これでチャートのサイズのしていができるようになる
   }
});
Chart.plugins.register({
    afterDatasetsDraw: function (chart, easing) {
        // To only draw at the end of animation, check for easing === 1
        var ctx = chart.ctx;

        chart.data.datasets.forEach(function (dataset, i) {
            var meta = chart.getDatasetMeta(i);
            if (!meta.hidden) {
                meta.data.forEach(function (element, index) {
                    // Draw the text in black, with the specified font
                    ctx.fillStyle = 'rgb(255, 255, 255)';

                    var fontSize = 15;
                    var fontStyle = 'normal';
                    var fontFamily = 'Helvetica Neue';
                    ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                    // Just naively convert to string for now
                    var dataString = dataset.data[index].toString();

                    // Make sure alignment settings are correct
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';

                    var padding = 5;
                    var position = element.tooltipPosition();
                    ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);
                });
            }
        });
    }
});
var ctx = document.getElementById("graph-area3").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
   labels: ["M", "T", "W"],
    datasets: [{
      backgroundColor: [
        "#fff33f",
        "#f39800",
        "#009e96"
      ],
      data: [22, 15, 3]
    }]
  },
  options: {
   maintainAspectRatio: false,     //これでチャートのサイズのしていができるようになる
   }
});
Chart.plugins.register({
    afterDatasetsDraw: function (chart, easing) {
        // To only draw at the end of animation, check for easing === 1
        var ctx = chart.ctx;

        chart.data.datasets.forEach(function (dataset, i) {
            var meta = chart.getDatasetMeta(i);
            if (!meta.hidden) {
                meta.data.forEach(function (element, index) {
                    // Draw the text in black, with the specified font
                    ctx.fillStyle = 'rgb(255, 255, 255)';

                    var fontSize = 15;
                    var fontStyle = 'normal';
                    var fontFamily = 'Helvetica Neue';
                    ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                    // Just naively convert to string for now
                    var dataString = dataset.data[index].toString();

                    // Make sure alignment settings are correct
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';

                    var padding = 5;
                    var position = element.tooltipPosition();
                    ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);
                });
            }
        });
    }
});
var ctx = document.getElementById("graph-area4").getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
   labels: ["M", "T", "W"],
    datasets: [{
      backgroundColor: [
        "#fff33f",
        "#f39800",
        "#009e96"
      ],
      data: [22, 15, 3]
    }]
  },
  options: {
   maintainAspectRatio: false,     //これでチャートのサイズのしていができるようになる
   }
});
Chart.plugins.register({
    afterDatasetsDraw: function (chart, easing) {
        // To only draw at the end of animation, check for easing === 1
        var ctx = chart.ctx;

        chart.data.datasets.forEach(function (dataset, i) {
            var meta = chart.getDatasetMeta(i);
            if (!meta.hidden) {
                meta.data.forEach(function (element, index) {
                    // Draw the text in black, with the specified font
                    ctx.fillStyle = 'rgb(255, 255, 255)';

                    var fontSize = 15;
                    var fontStyle = 'normal';
                    var fontFamily = 'Helvetica Neue';
                    ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

                    // Just naively convert to string for now
                    var dataString = dataset.data[index].toString();

                    // Make sure alignment settings are correct
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';

                    var padding = 5;
                    var position = element.tooltipPosition();
                    ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);
                });
            }
        });
    }
});